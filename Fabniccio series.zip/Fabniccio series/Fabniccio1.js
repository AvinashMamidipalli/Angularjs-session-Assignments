var firstNumber;
var secondNumber;
var Sum1;
function series(firstNumber, secondNumber) {
    'use strict';
    var i;
    console.log(firstNumber);
    console.log(secondNumber);
    for (i = 0; i < 20; i += 1) {
        
        Sum1 = firstNumber + secondNumber;
        firstNumber = secondNumber;
        secondNumber = Sum1;
        
        console.log(Sum1);
    }
}
series(1, 1);