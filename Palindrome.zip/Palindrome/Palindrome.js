var name;
var length;
var i;
var result = true;
function pallandrom(name) {
    'use strict';
    length = name.length;
    for (i = 0; i < Math.floor(length / 2); i += 1) {
        if (name[i] !== name[length - 1 - i]) {
            result = false;
            break;
        }
    }
    if (result === true) {
        console.log("name is palindrome");
    } else {
        console.log("name is not palindrome");
    }
}
pallandrom("111121111");
